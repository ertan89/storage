import urlparse
import sys,urllib
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import urlresolver

import glob

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

_addon = xbmcaddon.Addon()
_icon = _addon.getAddonInfo('icon')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def resolve_url(url):
    duration=7500   #in milliseconds
    message = "Cannot Play URL"
    stream_url = urlresolver.HostedMediaFile(url=url).resolve()
    # If urlresolver returns false then the video url was not resolved.
    if not stream_url:
        dialog = xbmcgui.Dialog()
        dialog.notification("URL Resolver Error", message, xbmcgui.NOTIFICATION_INFO, duration)
        return False
    else:        
        return stream_url    

def play_video(path):
    """
    Play a video by the provided path.
    :param path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    vid_url = play_item.getfilename()
    stream_url = resolve_url(vid_url)
    if stream_url:
        play_item.setPath(stream_url)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

# addon kicks in

mode = args.get('mode', None)

windows_project = 1

foldernames = []

if windows_project==1:
    txts_dir = 'C:\Users\Ertan\AppData\Roaming\Kodi\\addons\plugin.video.filmler\\txts\\'
    fullpaths = glob.glob(txts_dir+'*.txt')
    for fullpath in fullpaths:
        fullname = fullpath.split('\\')
        fullname = fullname[len(fullname)-1]
        name = fullname.split('.')
        name = name[0]
        foldernames.append(name)
else:
    txts_dir = '/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/addons/plugin.video.filmler/txts/'
    fullpaths = glob.glob(txts_dir + '*.txt')
    for fullpath in fullpaths:
        fullname = fullpath.split('/')
        fullname = fullname[len(fullname) - 1]
        name = fullname.split('.')
        name = name[0]
        foldernames.append(name)

if mode is None:
    for foldername in foldernames:
        url = build_url({'mode': 'folder', 'foldername': foldername})
        li = xbmcgui.ListItem(foldername, iconImage='DefaultFolder.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'folder':
    foldername = args['foldername'][0]

    vid_urls = []
    vid_names = []
    im_links = []

    with open(txts_dir+foldername+".txt", "r") as infile:
        content = infile.readlines()

    content = [x.strip() for x in content]

    counter = 0
    for c in content:
        if counter == 0:
            vid_names.append(c)
            counter = counter + 1
        elif counter == 1:
            vid_urls.append(c)
            counter = counter + 1
        elif counter == 2:
            im_links.append(c)
            counter = 0

    for vid_url, vid_name, im_link in zip(vid_urls, vid_names,im_links):
        video_play_url = vid_url
        url = build_url({'mode': 'play', 'playlink': video_play_url})
        li = xbmcgui.ListItem(vid_name, iconImage=im_link,thumbnailImage=im_link)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'play':
    final_link = args['playlink'][0]
    play_video(final_link)





